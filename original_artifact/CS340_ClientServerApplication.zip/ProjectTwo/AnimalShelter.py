from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,USER,PASS):
        # Connection Variables - Replace with your environment's values if needed
        USER = 'aacuser'
        PASS = 'Frontporch1'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32390
        DB = 'AAC'
        COL = 'animals'

        # Try to connect to MongoDB
        try:
            # This creates a connection to MongoDB using provided credentials
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=admin')
            self.database = self.client[DB]  # Select the database
            self.collection = self.database[COL]  # Select the collection
        except Exception as e:
            # If the connection fails, print the error
            print(f"Failed to connect to MongoDB: {e}")
            raise  # Re-raise the exception to stop execution if connection fails

    def create(self, data, lookup):
        """
        Inserts a new document into the 'animals' collection if it doesn't already exist.

        :param data: dict, the full document to insert
        :param lookup: dict, key/value pair to check for existing document using find()
        :return: True if inserted successfully, False otherwise
        """
        if not data or not isinstance(data, dict):
            raise ValueError("Invalid data: must be a non-empty dictionary.")
        if not lookup or not isinstance(lookup, dict):
            raise ValueError("Invalid lookup: must be a non-empty dictionary.")

        try:
            # Check for existing document using lookup pair
            if self.collection.find_one(lookup):
                return False  # Document already exists, do not insert

            # Insert new document
            result = self.collection.insert_one(data)
            return result.acknowledged
        except Exception as e:
            print(f"Error inserting document: {e}")
            return False


    def read(self, query: dict = None):
        """
        Retrieves documents from the 'animals' collection based on the query.
        :param query: dictionary specifying the search filter
        :return: list of matching documents, or an empty list if none found or error occurs
        """
        try:
            # If no query is provided, default to an empty query which returns all documents
            if query is None:
                query = {}

            # Attempt to retrieve matching documents using find()
            results = self.collection.find(query)

            # Convert MongoDB cursor to a list and return
            return list(results)
        except Exception as e:
            # Handles any unexpected issues, like invalid query syntax or connection issues
            print(f"Error reading documents: {e}")
            return []  # Return empty list to indicate failure

        
    def update(self, query: dict, update_data: dict):
        """
        Updates document(s) in the 'animals' collection based on the query.

        :param query: dictionary specifying the filter to match documents
        :param update_data: dictionary specifying the update operation (e.g., {'$set': {...}})
        :return: integer representing the number of modified documents
        """
        if not query or not isinstance(query, dict):
            raise ValueError("Invalid query: must be a non-empty dictionary.")
        if not update_data or not isinstance(update_data, dict):
            raise ValueError("Invalid update data: must be a non-empty dictionary.")

        try:
            # Use update_many to modify all documents matching the query
            result = self.collection.update_many(query, update_data)
            return result.modified_count  # Number of documents actually modified
        except Exception as e:
            print(f"Error updating documents: {e}")
            return 0  # Return 0 to indicate failure or no documents modified
        
    def delete(self, query: dict):
        """
        Deletes document(s) from the 'animals' collection based on the query.

        :param query: dictionary specifying the filter to match documents
        :return: integer representing the number of documents deleted
        """
        if not query or not isinstance(query, dict):
            raise ValueError("Invalid query: must be a non-empty dictionary.")

        try:
            # Use delete_many to remove all matching documents
            result = self.collection.delete_many(query)
            return result.deleted_count  # Number of documents actually deleted
        except Exception as e:
            print(f"Error deleting documents: {e}")
            return 0  # Return 0 to indicate failure or no deletions
